package com.example.dolfin;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
