import 'package:flutter/material.dart';

class OverallExpenseCard extends StatelessWidget {
  final double totalExpenses;
  final double maxBudget;

  OverallExpenseCard({required this.totalExpenses, required this.maxBudget});

  @override
  Widget build(BuildContext context) {
    double remainingBudget = maxBudget - totalExpenses;
    double percentageUsed = (totalExpenses / maxBudget).clamp(0.0, 1.0);

    return Card(
      margin: EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 10,
      color: _getBackgroundColor(percentageUsed),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Circular Progress Bar
            Container(
              height: 140,
              width: 140,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  // Circular background for aesthetics
                  Container(
                    height: 140,
                    width: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.grey[200],
                    ),
                  ),
                  CircularProgressIndicator(
                    value: percentageUsed,
                    strokeWidth: 16,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      _getProgressColor(percentageUsed),
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      border: Border.all(color: Colors.grey[200]!, width: 5),
                    ),
                    child: Center(
                      child: Text(
                        '${(percentageUsed * 100).toStringAsFixed(0)}%',
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Total Expenses',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    '\$${totalExpenses.toStringAsFixed(2)}',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Remaining Budget',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: Colors.grey[600],
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    '\$${remainingBudget.toStringAsFixed(2)}',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w600,
                      color: Colors.black54,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Determine background color based on percentage used
  Color _getBackgroundColor(double percentage) {
    if (percentage >= 1.0) {
      return Colors.red[100]!; // Light red for exceeded budget
    } else if (percentage >= 0.75) {
      return Colors.orange[100]!; // Light orange for high spending
    } else {
      return Colors.green[100]!; // Light green for within budget
    }
  }

  // Determine progress indicator color based on budget usage percentage
  Color _getProgressColor(double percentage) {
    if (percentage >= 1.0) {
      return Colors.red;
    } else if (percentage >= 0.75) {
      return Colors.orange;
    } else {
      return Colors.blue; // Default progress color
    }
  }
}
