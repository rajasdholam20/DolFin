import 'package:flutter/material.dart';

class ExpenseCard extends StatefulWidget {
  final String category;
  final List<Map<String, dynamic>> expenses;
  final double current;
  final double max;

  ExpenseCard({
    required this.category,
    required this.expenses,
    required this.current,
    required this.max,
  });

  @override
  _ExpenseCardState createState() => _ExpenseCardState();
}

class _ExpenseCardState extends State<ExpenseCard> {
  bool showHistory = false;

  Color _getProgressColor(double percentage) {
    if (percentage >= 1.0) {
      return Colors.red; // Exceeded budget
    } else if (percentage >= 0.75) {
      return Colors.orange; // High spending
    } else {
      return Colors.green; // Within budget
    }
  }

  @override
  Widget build(BuildContext context) {
    double percentage = (widget.current / widget.max).clamp(0.0, 1.0);
    Color progressColor = _getProgressColor(percentage);

    return Card(
      margin: EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 5,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.category,
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87),
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Current: \$${widget.current.toStringAsFixed(2)}',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                Text('Max: \$${widget.max.toStringAsFixed(2)}',
                    style:
                        TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ],
            ),
            SizedBox(height: 15),
            Container(
              height: 20,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.grey[300],
              ),
              child: Stack(
                children: [
                  Container(
                    width: percentage * MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: progressColor,
                    ),
                  ),
                  Center(
                    child: Text(
                      '${(percentage * 100).toStringAsFixed(0)}%',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 15),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  showHistory = !showHistory;
                });
              },
              child: Text(showHistory ? 'Hide History' : 'Show History'),
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.green,
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                textStyle: TextStyle(fontSize: 16),
              ),
            ),
            if (showHistory) ...[
              SizedBox(height: 15),
              Text('Expense Log',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              widget.expenses.isNotEmpty
                  ? ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: widget.expenses.length,
                      itemBuilder: (context, index) {
                        return Card(
                          margin: EdgeInsets.only(bottom: 8),
                          child: ListTile(
                            title: Text(
                                '${widget.expenses[index]['description']} - \$${widget.expenses[index]['amount']}'),
                            subtitle: Text(
                                '${DateTime.fromMillisecondsSinceEpoch(widget.expenses[index]['timestamp']).toString()}'),
                          ),
                        );
                      },
                    )
                  : Center(child: Text('No expenses recorded')),
            ],
          ],
        ),
      ),
    );
  }
}
