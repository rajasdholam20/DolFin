import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Method to store the rolled data in Firestore
  Future<void> storeRollData(String userId, DateTime rolledDateTime, double amount, int gems) async {
    try {
      await _firestore.collection('dice_rolls').add({
        'user_id': userId,
        'rolled_date_time': rolledDateTime,
        'amount': amount,
        'gems_earned': gems,
      });
    } catch (e) {
      print("Error storing roll data: $e");
    }
  }

  // Method to fetch roll history from Firestore
  Future<QuerySnapshot> fetchRollHistory(String userId) async {
    try {
      return await _firestore
          .collection('dice_rolls')
          .where('user_id', isEqualTo: userId)
          .orderBy('rolled_date_time', descending: true) // Sort by rolled date, most recent first
          .get();
    } catch (e) {
      print("Error fetching roll history: $e");
      throw e; // Rethrow the exception for handling elsewhere if needed
    }
  }
}