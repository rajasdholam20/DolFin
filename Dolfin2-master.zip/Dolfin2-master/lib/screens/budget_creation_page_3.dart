import 'package:flutter/material.dart';
import 'budget_creation_page_4.dart';

class BudgetCreationPage3 extends StatefulWidget {
  final String selectedTemplate;

  const BudgetCreationPage3({Key? key, required this.selectedTemplate}) : super(key: key);

  @override
  _BudgetCreationPage3State createState() => _BudgetCreationPage3State();
}

class _BudgetCreationPage3State extends State<BudgetCreationPage3> {
  final _formKey = GlobalKey<FormState>();
  final _budgetController = TextEditingController();
  double _currentBudget = 0;

  Map<String, Map<String, double>> _templateAllocation = {};

  @override
  void initState() {
    super.initState();
    _setTemplateAllocation();
    _budgetController.addListener(_updateAllocations);
  }

  void _setTemplateAllocation() {
    switch (widget.selectedTemplate) {
      case '50-20-20-10 Plan':
        _templateAllocation = {
          'Essentials': {
            'Housing': 0.30,
            'Groceries & Dining': 0.10,
            'Transportation': 0.05,
            'Healthcare': 0.05,
          },
          'Savings': {
            'Emergency Fund': 0.10,
            'Long-Term Savings': 0.05,
            'Retirement': 0.05,
          },
          'Personal': {
            'Entertainment': 0.10,
            'Hobbies & Personal Care': 0.10,
          },
          'Miscellaneous': {
            'Unexpected Costs': 0.05,
            'Gifts & Donations': 0.05,
          },
        };
        break;
      case '60-20-10-10 Plan':
        _templateAllocation = {
          'Essentials': {
            'Housing': 0.35,
            'Groceries & Dining': 0.15,
            'Transportation': 0.05,
            'Healthcare': 0.05,
          },
          'Savings': {
            'Emergency Fund': 0.10,
            'Long-Term Savings': 0.05,
            'Retirement': 0.05,
          },
          'Personal': {
            'Entertainment': 0.05,
            'Hobbies & Personal Care': 0.05,
          },
          'Miscellaneous': {
            'Unexpected Costs': 0.05,
            'Gifts & Donations': 0.05,
          },
        };
        break;
      case '40-30-20-10 Plan':
        _templateAllocation = {
          'Essentials': {
            'Housing': 0.20,
            'Groceries & Dining': 0.10,
            'Transportation': 0.05,
            'Healthcare': 0.05,
          },
          'Savings': {
            'Debt Repayment': 0.15,
            'Emergency Fund': 0.05,
            'Long-Term Savings': 0.05,
            'Retirement': 0.05,
          },
          'Personal': {
            'Entertainment': 0.10,
            'Hobbies & Personal Care': 0.10,
          },
          'Miscellaneous': {
            'Unexpected Costs': 0.05,
            'Gifts & Donations': 0.05,
          },
        };
        break;
    }
  }

  void _updateAllocations() {
    setState(() {
      _currentBudget = double.tryParse(_budgetController.text) ?? 0;
    });
  }

  @override
  void dispose() {
    _budgetController.removeListener(_updateAllocations);
    _budgetController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Monthly Budget'),
        backgroundColor: Colors.green,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Enter Your Monthly Budget',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                SizedBox(height: 16),
                Text(
                  'Please enter the total amount of money you have available to budget each month in Rupees. This will help us create a personalized budget plan based on your selected template (${widget.selectedTemplate}).',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                SizedBox(height: 24),
                TextFormField(
                  controller: _budgetController,
                  decoration: InputDecoration(
                    labelText: 'Monthly Budget',
                    prefixIcon: Icon(Icons.currency_rupee),
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your monthly budget';
                    }
                    if (double.tryParse(value) == null) {
                      return 'Please enter a valid number';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 24),
                ..._buildAllocationCards(),
                SizedBox(height: 24),
                Center(
                  child: ElevatedButton(
                    child: Text('Next', style: TextStyle(fontSize: 18)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => BudgetCreationPage4(
                              selectedTemplate: widget.selectedTemplate,
                              monthlyBudget: _currentBudget,
                              allocations: _templateAllocation,
                            ),
                          ),
                        );
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildAllocationCards() {
    List<Widget> cards = [];
    _templateAllocation.forEach((category, subcategories) {
      cards.add(
        Card(
          margin: EdgeInsets.only(bottom: 16),
          child: Column(
            children: [
              ListTile(
                title: Text(category, style: TextStyle(fontWeight: FontWeight.bold)),
                tileColor: Colors.grey[200],
              ),
              ...subcategories.entries.map((entry) {
                double allocatedAmount = _currentBudget * entry.value;
                return ListTile(
                  title: Text(entry.key),
                  trailing: Text(
                    '₹${allocatedAmount.toStringAsFixed(2)}',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text('${(entry.value * 100).toStringAsFixed(1)}% of budget'),
                );
              }).toList(),
            ],
          ),
        ),
      );
    });
    return cards;
  }
}