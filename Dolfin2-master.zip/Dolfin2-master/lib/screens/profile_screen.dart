import 'package:dolfin/screens/auth/fbauth.dart';
import 'package:dolfin/screens/auth/signin.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProfileScreen extends StatelessWidget {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Profile Picture
            Center(
              child: CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage(
                    'assets/images/vj.png'), // Replace with your image URL
              ),
            ),
            SizedBox(height: 16),
            // User Name
            Text(
              'Welcome!',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            // User Email
            Text(
              AuthHelper.user?.email ?? "Hello User!",
              style: TextStyle(fontSize: 20, color: Colors.grey[600]),
            ),
            SizedBox(height: 24),
            // Buttons
            ElevatedButton(
              onPressed: () {
                // Edit Profile Action
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              ),
              child: Text('Edit Profile'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () async {
                await _auth.signOut();
                // Get.offAll(LoginScreen());
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const LoginScreen(),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              ),
              child: Text('Logout'),
            ),
          ],
        ),
      ),
    );
  }
}
