import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../widgets/components/ExpenseCard.dart';
import '../widgets/components/OverallCard.dart';

class ExpensePage extends StatefulWidget {
  @override
  _ExpensePageState createState() => _ExpensePageState();
}

class _ExpensePageState extends State<ExpensePage> {
  double totalExpenses = 0;
  double maxBudget = 1000; // Default value in case Firestore fetch fails
  String selectedCategory = 'Miscellaneous';
  final List<String> categories = [
    'Miscellaneous',
    'Savings',
    'Personal',
    'Essential',
    'Others'
  ];

  // This will store expenses fetched from Firestore
  Map<String, List<Map<String, dynamic>>> categorizedExpenses = {
    'Miscellaneous': [],
    'Savings': [],
    'Personal': [],
    'Essential': [],
    'Others': [],
  };

  @override
  void initState() {
    super.initState();
    _fetchExpenses();
  }

  // Fetch expenses from Firestore
  Future<void> _fetchExpenses() async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        // Get the user's document from Firestore
        DocumentSnapshot userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();
        if (userDoc.exists) {
          // Fetching the user's monthlyBudget from Firestore
          double fetchedMonthlyBudget =
              userDoc['budget']['monthlyBudget'] ?? 0.0;

          // Update maxBudget with the fetched value
          setState(() {
            maxBudget = fetchedMonthlyBudget;
          });

          // Get the list of expenses from Firestore
          List<dynamic> expenses = userDoc['expenses'];

          // Categorize expenses based on their type
          setState(() {
            categorizedExpenses = {
              'Miscellaneous': [],
              'Savings': [],
              'Personal': [],
              'Essential': [],
              'Others': [],
            };

            // Loop through each expense and categorize it
            expenses.forEach((expense) {
              String category = expense['category'];
              if (categorizedExpenses.containsKey(category)) {
                categorizedExpenses[category]?.add(expense);
              }
            });

            // Calculate the total expenses
            totalExpenses = expenses.fold(0.0, (sum, expense) {
              return sum + double.tryParse(expense['amount'].toString())!;
            });
          });
        }
      }
    } catch (e) {
      print("Error fetching expenses: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          // Overall Expense Card
          OverallExpenseCard(
            totalExpenses: totalExpenses,
            maxBudget: maxBudget,
          ),
          SizedBox(height: 20),

          // Horizontal scrollable category buttons
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: categories.map((category) {
                bool isSelected = selectedCategory == category;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4.0),
                  child: ElevatedButton(
                    onPressed: () {
                      setState(() {
                        selectedCategory = category;
                      });
                    },
                    style: ElevatedButton.styleFrom(
                      foregroundColor: isSelected ? Colors.white : Colors.black,
                      backgroundColor: isSelected ? Colors.green : Colors.white,
                      side: BorderSide(color: Colors.green),
                      padding:
                          EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text(
                      category,
                      style:
                          TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          SizedBox(height: 20),

          // Displaying Expense Cards based on selected category
          if (selectedCategory == 'Miscellaneous')
            ExpenseCard(
              category: 'Miscellaneous',
              expenses: categorizedExpenses['Miscellaneous']!,
              current: categorizedExpenses['Miscellaneous']!.fold(
                  0.0,
                  (sum, expense) =>
                      sum + double.tryParse(expense['amount'].toString())!),
              max: 1500, // Example max budget for this category
            ),
          if (selectedCategory == 'Savings')
            ExpenseCard(
              category: 'Savings',
              expenses: categorizedExpenses['Savings']!,
              current: categorizedExpenses['Savings']!.fold(
                  0.0,
                  (sum, expense) =>
                      sum + double.tryParse(expense['amount'].toString())!),
              max: 1000, // Example max budget for this category
            ),
          if (selectedCategory == 'Personal')
            ExpenseCard(
              category: 'Personal',
              expenses: categorizedExpenses['Personal']!,
              current: categorizedExpenses['Personal']!.fold(
                  0.0,
                  (sum, expense) =>
                      sum + double.tryParse(expense['amount'].toString())!),
              max: 2000, // Example max budget for this category
            ),
          if (selectedCategory == 'Essential')
            ExpenseCard(
              category: 'Essential',
              expenses: categorizedExpenses['Essential']!,
              current: categorizedExpenses['Essential']!.fold(
                  0.0,
                  (sum, expense) =>
                      sum + double.tryParse(expense['amount'].toString())!),
              max: 500, // Example max budget for this category
            ),
        ],
      ),
    );
  }
}
