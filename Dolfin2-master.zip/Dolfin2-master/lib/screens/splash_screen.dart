import 'package:flutter/material.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:page_transition/page_transition.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dolfin/screens/onboard/onboard.dart';
import 'package:dolfin/screens/expense_tracker_screen.dart';
import 'package:dolfin/screens/auth/signup.dart';

class SplashScreen extends StatelessWidget {
  Future<Widget> _getNextScreen() async {
    // Check if user is logged in
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      // User is logged in, go to expense tracking page
      return ExpenseTrackerScreen();
    } else {
      // User is not logged in, check if they're a new user
      SharedPreferences prefs = await SharedPreferences.getInstance();
      bool isNewUser = !prefs.containsKey('onBoard');

      if (isNewUser) {
        // New user, go to intro page
        return OnBoardingScreen();
      } else {
        // Existing user, but not logged in, go to sign up screen
        return SignupScreen();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSplashScreen(
      duration: 3000,
      splash: Image.asset('assets/images/logo.png'),
      splashIconSize: 400,
      nextScreen: FutureBuilder<Widget>(
        future: _getNextScreen(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return snapshot.data ?? OnBoardingScreen(); // Fallback to OnBoardingScreen if null
          }
          // You can show a loading indicator here if needed
          return CircularProgressIndicator();
        },
      ),
      splashTransition: SplashTransition.fadeTransition,
      pageTransitionType: PageTransitionType.fade,
      backgroundColor: Colors.white,
    );
  }
}