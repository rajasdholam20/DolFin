import 'package:flutter/material.dart';

class LeaderboardScreen extends StatelessWidget {
  final List<Map<String, String>> diceChallengeTopUsers = [
    {'name': 'Alice', 'score': '1500'},
    {'name': 'Bob', 'score': '1200'},
    {'name': 'Charlie', 'score': '1100'},
  ];

  final List<Map<String, String>> hiLoTopScorers = [
    {'name': 'Dave', 'score': '1800'},
    {'name': 'Eve', 'score': '1600'},
    {'name': 'Frank', 'score': '1400'},
  ];

  final List<Map<String, String>> allTimeHighScorers = [
    {'name': 'Grace', 'score': '2000'},
    {'name': 'Heidi', 'score': '1900'},
    {'name': 'Ivan', 'score': '1700'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          _buildSection('Top Scorers for Dice Challenge', diceChallengeTopUsers),
          _buildSection('Top Scorers for Hi-Lo Challenge', hiLoTopScorers),
          _buildSection('All Time High Scorers', allTimeHighScorers),
        ],
      ),
    );
  }

  Widget _buildSection(String title, List<Map<String, String>> users) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 2,
            blurRadius: 5,
            offset: Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Color(0xFF6A1B9A),
            ),
          ),
          SizedBox(height: 10),
          Column(
            children: users.map((user) => _buildLeaderboardTile(user)).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildLeaderboardTile(Map<String, String> user) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 4),
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        contentPadding: EdgeInsets.all(12),
        leading: CircleAvatar(
          backgroundColor: Colors.primaries[
          (user['name']?.length ?? 0) % Colors.primaries.length],
          child: Text(
            user['name']![0],
            style: TextStyle(color: Colors.white),
          ),
        ),
        title: Text(
          user['name']!,
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        trailing: Text(
          user['score']!,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Color(0xFF6A1B9A),
          ),
        ),
      ),
    );
  }
}
