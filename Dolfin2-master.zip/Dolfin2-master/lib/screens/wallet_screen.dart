import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class WalletScreen extends StatefulWidget {
  final double initialAmount;
  final int gemsToAdd; // New parameter with a default value

  WalletScreen(
      {required this.initialAmount,
      required String userId,
      this.gemsToAdd = 5});

  @override
  _WalletScreenState createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  double walletBalance = 0.0;
  int gems = 0;
  List<Map<String, dynamic>> transactions = [];

  final _amountController = TextEditingController();
  final _upiPinController = TextEditingController();
  String? _selectedBankAccount;

  final List<String> bankAccounts = [
    'Bank Account 1',
    'Bank Account 2',
    'Bank Account 3'
  ];

  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    // Pre-fill the dice roll amount in the text field
    _amountController.text = widget.initialAmount.toStringAsFixed(2);
    _fetchUserData();
  }

  @override
  void dispose() {
    _amountController.dispose();
    _upiPinController.dispose();
    super.dispose();
  }

  Future<void> _fetchUserData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        setState(() {
          _error = 'Please sign in to view wallet details';
          _isLoading = false;
        });
        return;
      }

      final docSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();

      if (!mounted) return;

      if (docSnapshot.exists) {
        final data = docSnapshot.data() as Map<String, dynamic>;
        setState(() {
          walletBalance = (data['wallet_balance'] ?? 0).toDouble();
          gems = (data['gems'] ?? 0).toInt();
          transactions = List<Map<String, dynamic>>.from(
              data['transactions'] ?? []); // Load transactions
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'No user data found';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _updateUserData(double newBalance, int newGems) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        throw 'Please sign in to update wallet';
      }

      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .update({
        'wallet_balance': newBalance.toDouble(),
        'gems': newGems.toInt(),
        'transactions': transactions, // Save transactions to Firestore
      });

      if (!mounted) return;

      setState(() {
        walletBalance = newBalance;
        gems = newGems;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error updating wallet: $e')),
      );
    }
  }

  Future<void> _simulateTransfer(bool toWallet) async {
    double enteredAmount = double.tryParse(_amountController.text) ?? 0.0;

    if (enteredAmount > 0 && _selectedBankAccount != null) {
      double newBalance;
      int newGems;
      if (toWallet) {
        newBalance = walletBalance + enteredAmount;
        newGems = gems + widget.gemsToAdd; // Use gemsToAdd from the constructor
      } else {
        if (walletBalance >= enteredAmount) {
          newBalance = walletBalance - enteredAmount;
          newGems = gems;
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Insufficient balance in the wallet')),
          );
          return;
        }
      }

      // Add transaction to the list
      transactions.add({
        'amount': enteredAmount,
        'type': toWallet ? 'Added to Wallet' : 'Transferred to Bank',
        'date': DateTime.now().toIso8601String(),
      });

      // Update the user data with the new balance, gems, and transactions
      await _updateUserData(newBalance, newGems);

      _amountController.clear();
      _upiPinController.clear();
      _selectedBankAccount = null;

      await Future.delayed(Duration(seconds: 2));

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Transaction successful')),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content:
                Text('Please enter a valid amount and select a bank account')),
      );
    }
  }

  Future<void> _showBankSelectionPopup(bool toWallet) async {
    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setDialogState) {
            return AlertDialog(
              title: Text('Select Bank Account'),
              content: DropdownButton<String>(
                isExpanded: true,
                value: _selectedBankAccount,
                hint: Text('Choose a bank account'),
                items: bankAccounts.map((String account) {
                  return DropdownMenuItem<String>(
                    value: account,
                    child: Text(account),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setDialogState(() {
                    _selectedBankAccount = value;
                  });
                },
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    if (_selectedBankAccount != null) {
                      Navigator.of(context).pop();
                      if (toWallet) {
                        _showUPIPinPopup(toWallet);
                      } else {
                        _simulateTransfer(toWallet);
                      }
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Please select a bank account')),
                      );
                    }
                  },
                  child: Text('Next'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _showUPIPinPopup(bool toWallet) async {
    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Enter UPI PIN'),
          content: TextField(
            controller: _upiPinController,
            obscureText: true,
            decoration: InputDecoration(
              hintText: 'Enter UPI PIN',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                if (_upiPinController.text.isNotEmpty) {
                  Navigator.of(context).pop();
                  _simulateTransfer(toWallet);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Please enter UPI PIN')),
                  );
                }
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _error!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _fetchUserData,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildWalletHeader(),
            SizedBox(height: 20),
            _buildTransferSection(),
            SizedBox(height: 30),
            _buildTransactionHistory(),
          ],
        ),
      ),
    );
  }

  Widget _buildWalletHeader() {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xFF66BB6A),
        borderRadius: BorderRadius.circular(10),
      ),
      padding: EdgeInsets.all(20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Wallet Balance',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Rs. $walletBalance',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                'Gems',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFFFFA726),
                ),
              ),
              SizedBox(height: 8),
              Text(
                gems.toString(),
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFFFFA726),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTransferSection() {
    return Container(
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 10,
          ),
        ],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Enter Amount',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Color(0xFF4CAF50),
            ),
          ),
          SizedBox(height: 10),
          TextField(
            controller: _amountController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              hintText: 'Rs. 0.00',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8.0),
                borderSide: BorderSide(color: Color(0xFF4CAF50)),
              ),
            ),
          ),
          SizedBox(height: 16),
          ElevatedButton(
            onPressed: () {
              _showBankSelectionPopup(true);
            },
            child: Text('Add to Wallet'),
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white,
              backgroundColor: Color(0xFF4CAF50),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              _showBankSelectionPopup(false);
            },
            child: Text('Transfer to Bank'),
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white,
              backgroundColor: Color(0xFF4CAF50),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionHistory() {
    return Expanded(
      child: ListView.builder(
        itemCount: transactions.length,
        itemBuilder: (context, index) {
          var transaction = transactions[index];
          // Convert the date string to DateTime
          var dateString = transaction['date'] as String;
          var date = DateTime.parse(dateString); // Convert String to DateTime
          var formattedDate = DateFormat('dd MMM yyyy, hh:mm a').format(date);

          return ListTile(
            leading: CircleAvatar(
              backgroundColor: transaction['type'] == 'Added to Wallet'
                  ? Color(0xFF4CAF50)
                  : Color(0xFFE53935),
              child: Icon(
                transaction['type'] == 'Added to Wallet'
                    ? Icons.add
                    : Icons.remove,
                color: Colors.white,
              ),
            ),
            title: Text(
              transaction['type'],
              style: TextStyle(
                color: Color(0xFF4CAF50),
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(formattedDate), // Use the formatted date
            trailing: Text(
              'Rs. ${transaction['amount'].toStringAsFixed(2)}',
              style: TextStyle(
                color: Color(0xFF4CAF50),
                fontWeight: FontWeight.bold,
              ),
            ),
          );
        },
      ),
    );
  }
}
