import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class HiLoChallengePage extends StatefulWidget {
  @override
  _HiLoChallengePageState createState() => _HiLoChallengePageState();
}

class _HiLoChallengePageState extends State<HiLoChallengePage> {
  int _currentQuestionIndex = 0; // Current question index
  int _score = 0; // User's score
  List<Map<String, dynamic>> _questions = []; // Change Object to dynamic

  @override
  void initState() {
    super.initState();
    _fetchQuestions(); // Fetch questions when the widget is initialized
  }

  // Fetch quiz questions from Firebase Firestore
  Future<void> _fetchQuestions() async {
    try {
      FirebaseFirestore firestore = FirebaseFirestore.instance;
      QuerySnapshot snapshot = await firestore.collection('quiz_questions').get();

      // Map fetched documents to the required format
      List<Map<String, dynamic>> fetchedQuestions = snapshot.docs.map((doc) {
        return {
          'question': doc['question'] ?? 'No question provided',
          'correctAnswer': doc['correctAnswer'] ?? 'No answer provided',
          'explanation': doc['explanation'] ?? 'No explanation provided',
        };
      }).toList();

      setState(() {
        _questions = fetchedQuestions; // Set the fetched questions to the state
      });
    } catch (e) {
      // Handle any errors that occur during fetching
      print('Error fetching questions: $e');
    }
  }

  // Method to go to the next question
  void _nextQuestion() {
    setState(() {
      if (_currentQuestionIndex < _questions.length - 1) {
        _currentQuestionIndex++; // Increment only if not the last question
      }
    });
  }

  // Check the user's answer
  void _checkAnswer(String answer) {
    if (answer == _questions[_currentQuestionIndex]['correctAnswer']) {
      _score++;
      _showCorrectDialog(); // Show dialog for correct answer
    } else {
      _showExplanationDialog(); // Show explanation for incorrect answer
    }
  }

  // Show dialog for correct answers
  void _showCorrectDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Correct!"),
        content: Text("Your answer is correct!"),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop(); // Close the dialog
              _checkForEndOfQuiz(); // Check if the quiz has ended after the dialog
            },
            child: Text("Next Question"),
          ),
        ],
      ),
    );
  }

  // Show explanation dialog for incorrect answers
  void _showExplanationDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Explanation"),
        content: Text(_questions[_currentQuestionIndex]['explanation'] as String),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop(); // Close the dialog
              _checkForEndOfQuiz(); // Check if the quiz has ended after the dialog
            },
            child: Text("Next Question"),
          ),
        ],
      ),
    );
  }

  // Check if all questions are answered and navigate to the ScoreScreen
  void _checkForEndOfQuiz() {
    if (_currentQuestionIndex < _questions.length - 1) {
      _nextQuestion(); // Move to the next question if not the last one
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ScoreScreen(_score, _questions.length),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Finance Quiz'),
        centerTitle: true,
      ),
      body: _questions.isEmpty
          ? Center(child: CircularProgressIndicator()) // Show loading indicator until questions are fetched
          : _currentQuestionIndex < _questions.length
          ? Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Text(
              _questions[_currentQuestionIndex]['question'] as String,
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                  ),
                  onPressed: () => _checkAnswer("Higher"),
                  child: Text('Higher', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
                  ),
                  onPressed: () => _checkAnswer("Lower"),
                  child: Text('Lower', style: TextStyle(fontSize: 20)),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          IconButton(
            icon: Icon(Icons.arrow_forward),
            iconSize: 50,
            onPressed: _nextQuestion,
          ),
        ],
      )
          : ScoreScreen(_score, _questions.length), // Navigate to score screen when done
    );
  }
}

// Score screen to display the user's score
class ScoreScreen extends StatelessWidget {
  final int score; // User's score
  final int totalQuestions; // Total number of questions

  ScoreScreen(this.score, this.totalQuestions);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Quiz Completed'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Your Score is:',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            Text(
              '$score / $totalQuestions',
              style: TextStyle(fontSize: 50, color: Colors.blueAccent),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Navigate back
              },
              child: Text('Retake Quiz'),
            ),
          ],
        ),
      ),
    );
  }
}