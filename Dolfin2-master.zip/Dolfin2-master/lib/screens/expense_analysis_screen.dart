import 'package:flutter/material.dart';

class ExpenseAnalysisScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text('Expense Analysis Page'),
    );
  }
}
