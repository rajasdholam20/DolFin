import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'dart:math';
import 'package:dice_icons/dice_icons.dart';

import 'wallet_screen.dart';

class DiceRollChallengePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Roll n\' Stash',
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: Colors.green.shade50,
        textTheme: TextTheme(
          bodyMedium: TextStyle(color: Colors.green.shade900),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            foregroundColor: Colors.white,
            backgroundColor: Colors.green.shade700,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
      ),
      home: RollNStashScreen(),
    );
  }
}

class RollNStashScreen extends StatefulWidget {
  @override
  _RollNStashScreenState createState() => _RollNStashScreenState();
}

class _RollNStashScreenState extends State<RollNStashScreen>
    with AutomaticKeepAliveClientMixin {
  int rolledNumber = 0;
  int totalSavings = 0;
  List<Map<String, dynamic>> history = [];
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  DateTime? lastRolledTime;
  Duration remainingTime = Duration.zero;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _fetchRollHistory();
  }

  Future<void> _fetchRollHistory() async {
    String userId = _auth.currentUser?.uid ?? 'unknown';
    QuerySnapshot snapshot = await _firestore
        .collection('dice_rolls')
        .where('user_id', isEqualTo: userId)
        .orderBy('rolled_date_time', descending: true)
        .get();

    setState(() {
      // Map the history from Firestore
      history = snapshot.docs.map((doc) {
        return {
          'date': (doc['rolled_date_time'] as Timestamp).toDate(),
          'amount': doc['amount'],
        };
      }).toList();

      // Calculate the total savings from the history
      totalSavings =
          history.fold(0, (sum, item) => sum + (item['amount'] as int));

      // Update the last rolled time
      if (history.isNotEmpty) {
        lastRolledTime = history.first['date'] as DateTime;
        _checkCooldown();
      }
    });
  }

  void _checkCooldown() {
    if (lastRolledTime != null) {
      DateTime now = DateTime.now();
      DateTime nextRollTime = lastRolledTime!.add(Duration(hours: 24));

      if (now.isBefore(nextRollTime)) {
        setState(() {
          remainingTime = nextRollTime.difference(now);
        });
        _startCooldownTimer();
      }
    }
  }

  void _startCooldownTimer() {
    Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        remainingTime = remainingTime - Duration(seconds: 1);

        if (remainingTime.isNegative) {
          remainingTime = Duration.zero;
          timer.cancel();
        }
      });
    });
  }

  void rollDice() {
    setState(() {
      rolledNumber = Random().nextInt(6) + 1;
      int savings = rolledNumber * 10;
      totalSavings += savings;

      String userId = _auth.currentUser?.uid ?? 'unknown';
      DateTime rolledDateTime = DateTime.now();
      _firestore.collection('dice_rolls').add({
        'user_id': userId,
        'rolled_date_time': rolledDateTime,
        'amount': savings,
        'gems_earned': 10, // Example gems earned value
      });

      lastRolledTime = rolledDateTime;
      remainingTime = Duration(hours: 24);
      _startCooldownTimer();
      _fetchRollHistory(); // Refresh the history
    });
  }

  Widget buildHistory() {
    return history.isNotEmpty
        ? DataTable(
            columns: [
              DataColumn(label: Text('Date')),
              DataColumn(label: Text('Amount')),
            ],
            rows: history.map((entry) {
              return DataRow(cells: [
                DataCell(Text(DateFormat('dd-MM-yyyy').format(entry['date']))),
                DataCell(Text('₹${entry['amount']}')),
              ]);
            }).toList(),
          )
        : Center(child: Text('No history yet! Roll the dice to start saving.'));
  }

  IconData getDiceIcon(int number) {
    switch (number) {
      case 1:
        return DiceIcons.dice1;
      case 2:
        return DiceIcons.dice2;
      case 3:
        return DiceIcons.dice3;
      case 4:
        return DiceIcons.dice4;
      case 5:
        return DiceIcons.dice5;
      case 6:
        return DiceIcons.dice6;
      default:
        return DiceIcons.dice0;
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('Roll n\' Stash'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Roll a die and save 10x the number you get. Roll a 5? Save ₹50!',
              style: TextStyle(fontSize: 18, color: Colors.green.shade800),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20),
            GestureDetector(
              onTap: remainingTime == Duration.zero ? rollDice : null,
              child: Column(
                children: [
                  Icon(
                    getDiceIcon(rolledNumber),
                    size: 100,
                    color: Colors.green.shade700,
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Tap to Roll',
                    style: TextStyle(
                      fontSize: 16,
                      color: remainingTime == Duration.zero
                          ? Colors.green.shade900
                          : Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 10),
            remainingTime == Duration.zero
                ? Text(
                    'Roll the dice to start saving!',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade800,
                    ),
                  )
                : Text(
                    'Cooldown active.\nNext roll in ${remainingTime.inHours}h ${remainingTime.inMinutes % 60}m.',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.red.shade700,
                    ),
                    textAlign: TextAlign.center,
                  ),
            SizedBox(height: 20),
            Divider(),
            Expanded(
              child: Column(
                children: [
                  Text(
                    'Total Savings: ₹$totalSavings',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.green.shade900,
                    ),
                  ),
                  SizedBox(height: 10),
                  Expanded(child: buildHistory()),
                ],
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: rolledNumber > 0
                  ? () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => WalletScreen(
                            initialAmount: (rolledNumber * 10).toDouble(),
                            userId: _auth.currentUser?.uid ?? '',
                            gemsToAdd: 10, // Pass 10 gems here
                          ),
                        ),
                      );
                    }
                  : null,
              child: Text('Add ₹${rolledNumber * 10} to Wallet'),
            ),
          ],
        ),
      ),
    );
  }
}
