import 'package:flutter/material.dart';
import 'budget_creation_page_3.dart';

class BudgetCreationPage2 extends StatefulWidget {
  @override
  _BudgetCreationPage2State createState() => _BudgetCreationPage2State();
}

class _BudgetCreationPage2State extends State<BudgetCreationPage2> {
  int? selectedTemplateIndex;

  final List<Map<String, dynamic>> templates = [
    {
      'title': '50-20-20-10 Plan',
      'description': '50% Essentials, 20% Savings, 20% Personal Spending, 10% Miscellaneous. A balanced approach to allocate funds based on general spending needs.',
      'color': Colors.lightGreen[600],
    },
    {
      'title': '60-20-10-10 Plan',
      'description': '60% Essentials, 20% Savings, 10% Personal Spending, 10% Miscellaneous. Ideal for those with high fixed costs such as rent or mortgage.',
      'color': Colors.teal[400],
    },
    {
      'title': '40-30-20-10 Plan',
      'description': '40% Essentials, 30% Savings, 20% Personal Spending, 10% Miscellaneous. Suited for individuals focused on aggressive savings and debt reduction.',
      'color': Colors.green[700],
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('Choose a Budget Template'),
        backgroundColor: Colors.green[700],
        elevation: 0,
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Intro Section
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                'Budgeting helps you allocate funds effectively, ensuring you stay within your means while achieving financial goals. Select a plan that best fits your lifestyle.',
                style: TextStyle(fontSize: 16, color: Colors.grey[700]),
                textAlign: TextAlign.center,
              ),
            ),
            // Budget Templates List
            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.all(16),
                itemCount: templates.length,
                itemBuilder: (context, index) {
                  return _buildTemplateCard(index);
                },
              ),
            ),
            // Next Button
            Padding(
              padding: EdgeInsets.all(16),
              child: ElevatedButton(
                child: Text('Next', style: TextStyle(fontSize: 18)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green[700],
                  padding: EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  elevation: 5,
                ),
                onPressed: selectedTemplateIndex != null
                    ? () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => BudgetCreationPage3(
                        selectedTemplate: templates[selectedTemplateIndex!]['title'],
                      ),
                    ),
                  );
                }
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTemplateCard(int index) {
    bool isSelected = selectedTemplateIndex == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedTemplateIndex = index;
        });
      },
      child: Container(
        margin: EdgeInsets.only(bottom: 16),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? templates[index]['color']!.withOpacity(0.1) : Colors.white,
          border: Border.all(
            color: isSelected ? templates[index]['color']! : Colors.grey[300]!,
            width: 2,
          ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: isSelected
              ? [
            BoxShadow(
              color: templates[index]['color']!.withOpacity(0.2),
              blurRadius: 10,
              spreadRadius: 2,
            )
          ]
              : [],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              templates[index]['title'],
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: templates[index]['color'],
              ),
            ),
            SizedBox(height: 8),
            Text(
              templates[index]['description'],
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[800],
              ),
            ),
            if (isSelected)
              Align(
                alignment: Alignment.centerRight,
                child: Icon(Icons.check_circle, color: templates[index]['color']),
              ),
          ],
        ),
      ),
    );
  }
}
