import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dolfin/screens/challenge_participation_page.dart';
import 'package:dolfin/screens/dice_roll_challenge_page.dart';
import 'package:dolfin/screens/hi_lo_challenge_page.dart';

class ChallengesScreen extends StatefulWidget {
  @override
  _ChallengesScreenState createState() => _ChallengesScreenState();
}

class _ChallengesScreenState extends State<ChallengesScreen> {
  // Filter options
  List<String> filters = ['All', 'Daily', 'Weekly', 'Monthly'];
  String selectedFilter = 'All';

  // Firebase Firestore instance
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFe8f5e9), Color(0xFFa5d6a7)], // Green gradient
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Filter Bubbles
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: filters.map((filter) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6.0),
                      child: ChoiceChip(
                        label: Text(filter),
                        selected: selectedFilter == filter,
                        onSelected: (isSelected) {
                          setState(() {
                            selectedFilter = filter;
                          });
                        },
                        selectedColor: Color(0xFF66bb6a),
                        backgroundColor: Color(0xFFc8e6c9),
                        labelStyle: TextStyle(
                          color: selectedFilter == filter
                              ? Colors.white
                              : Color(0xFF2e7d32),
                        ),
                        elevation: 3,
                      ),
                    );
                  }).toList(),
                ),
              ),
              SizedBox(height: 20),
              // Challenges based on filters
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream:
                      _firestore.collection('community_challenges').snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    }

                    if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                      return Center(child: Text('No challenges available.'));
                    }

                    // Filter challenges
                    List<QueryDocumentSnapshot> challenges =
                        snapshot.data!.docs;
                    if (selectedFilter != 'All') {
                      challenges = challenges.where((doc) {
                        return doc['type'] == selectedFilter;
                      }).toList();
                    }

                    return ListView(
                      children: challenges.map((doc) {
                        return _buildChallengeCard(
                          title: doc['title'],
                          description: doc['desc'],
                          gems: doc['gems'],
                          expiry: doc['type'] == 'Daily'
                              ? 'Renews in a Day'
                              : 'Renews in a Week',
                          isTemporary: true,
                        );
                      }).toList(),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildChallengeCard({
    required String title,
    required String description,
    required int gems,
    required String expiry,
    required bool isTemporary,
  }) {
    return Card(
      elevation: 6,
      shadowColor: Colors.black26,
      margin: EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF66bb6a), Color(0xFF81c784)], // Green gradient
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(15),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 8),
              Text(
                description,
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white70,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Gems: $gems',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white70,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Expiry: $expiry',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white70,
                ),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () {
                  // Navigate to different pages based on the challenge title or type
                  if (title == 'Dice Roll Challenge') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            DiceRollChallengePage(), // Redirect to Dice Roll Challenge Page
                      ),
                    );
                  } else if (title == 'Hi-Lo Challenge') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            HiLoChallengePage(), // Redirect to Hi-Lo Challenge Page
                      ),
                    );
                  } else {
                    // Default to the ChallengeParticipationPage
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ChallengeParticipationPage(
                          title: title,
                          description: description,
                          gems: gems,
                          expiry: expiry,
                        ),
                      ),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF388e3c),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: Text(
                  'Participate',
                  style: TextStyle(
                    color: Colors.white, // Set the text color to white
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
