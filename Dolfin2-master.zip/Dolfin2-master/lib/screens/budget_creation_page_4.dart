import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'expense_tracker_screen.dart';

class BudgetCreationPage4 extends StatelessWidget {
  final String selectedTemplate;
  final double monthlyBudget;
  final Map<String, Map<String, double>> allocations;

  const BudgetCreationPage4({
    Key? key,
    required this.selectedTemplate,
    required this.monthlyBudget,
    required this.allocations,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Budget Summary'),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your Budget Plan',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            SizedBox(height: 8),
            Text(
              'Template: $selectedTemplate',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(
              'Total Monthly Budget: ₹${monthlyBudget.toStringAsFixed(2)}',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            SizedBox(height: 24),
            Text(
              'Detailed Allocation Breakdown:',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            SizedBox(height: 16),
            ...allocations.entries.map((category) {
              return Card(
                margin: EdgeInsets.only(bottom: 16),
                child: Column(
                  children: [
                    ListTile(
                      title: Text(category.key, style: TextStyle(fontWeight: FontWeight.bold)),
                      tileColor: Colors.grey[200],
                    ),
                    ...category.value.entries.map((subcategory) {
                      double allocatedAmount = monthlyBudget * subcategory.value;
                      double weeklyAmount = allocatedAmount / 4;
                      return ListTile(
                        title: Text(subcategory.key),
                        trailing: Text(
                          '₹${allocatedAmount.toStringAsFixed(2)}',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${(subcategory.value * 100).toStringAsFixed(1)}% of budget'),
                            SizedBox(height: 4),
                            Text(
                              'Weekly: ₹${weeklyAmount.toStringAsFixed(2)}',
                              style: TextStyle(color: Colors.grey[700]),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ],
                ),
              );
            }).toList(),
            SizedBox(height: 24),
            Center(
              child: ElevatedButton(
                child: Text('Finish', style: TextStyle(fontSize: 18)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  padding: EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                onPressed: () async {
                  try {
                    // Retrieve the current user's ID
                    final user = FirebaseAuth.instance.currentUser;
                    if (user == null) {
                      throw Exception("User is not logged in");
                    }

                    // Reference to Firestore
                    final firestore = FirebaseFirestore.instance;

                    // Structure the budget data to be saved as a nested field
                    final budgetData = {
                      'budget': {
                        'selectedTemplate': selectedTemplate,
                        'monthlyBudget': monthlyBudget,
                        'allocations': allocations.map((key, value) => MapEntry(
                          key,
                          value.map((k, v) => MapEntry(k, v)),
                        )),
                        'createdAt': FieldValue.serverTimestamp(),
                      }
                    };

                    // Store the budget data under the current user's document in the "users" collection
                    await firestore
                        .collection('users')
                        .doc(user.uid) // Reference to the specific user's document
                        .set(
                      budgetData, // Nest the budget data under a specific field
                      SetOptions(merge: true), // Use merge to avoid overwriting existing data
                    );

                    // Navigate to the Expense Tracker page on success
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ExpenseTrackerScreen(),
                      ),
                    );
                  } catch (e) {
                    // Display an error message if something goes wrong
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Error: ${e.toString()}')),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
