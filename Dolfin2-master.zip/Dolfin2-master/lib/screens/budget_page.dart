import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class BudgetPage extends StatefulWidget {
  @override
  _BudgetPageState createState() => _BudgetPageState();
}

class _BudgetPageState extends State<BudgetPage> {
  final TextEditingController _monthlyBudgetController =
      TextEditingController();
  bool _isEditing = false;
  Map<String, dynamic> _budget = {};
  bool _isLoading = true;
  String? _error;
  String? _selectedTemplate;

  @override
  void initState() {
    super.initState();
    _fetchBudgetDetails();
  }

  Future<void> _fetchBudgetDetails() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        setState(() {
          _error = 'Please sign in to view budget details';
          _isLoading = false;
        });
        return;
      }

      final docSnapshot = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();

      if (!mounted) return;

      if (docSnapshot.exists) {
        final data = docSnapshot.data() as Map<String, dynamic>;
        setState(() {
          _budget = data['budget'] ?? {};
          _selectedTemplate = _budget['selectedTemplate'] as String?;
          _monthlyBudgetController.text =
              (data['budget']['monthlyBudget'] ?? 0).toString();
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'No user data found';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  Future<void> _updateBudget() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please sign in to update budget')),
      );
      return;
    }

    try {
      final newBudget = double.tryParse(_monthlyBudgetController.text);
      if (newBudget == null || newBudget <= 0) {
        throw 'Please enter a valid budget amount';
      }

      // Prepare the data to update
      Map<String, dynamic> updatedData = {
        'budget.monthlyBudget': newBudget,
      };

      if (_selectedTemplate != _budget['selectedTemplate']) {
        updatedData.addAll({
          'budget.selectedTemplate': _selectedTemplate,
          'budget.allocations': _getTemplateAllocation(_selectedTemplate),
        });
      }

      // Update in Firestore
      await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .update(updatedData);

      if (!mounted) return;

      setState(() {
        _isEditing = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Budget updated successfully!')),
      );

      // Refresh the data
      _fetchBudgetDetails();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error updating budget: $e')),
      );
    }
  }

  Map<String, dynamic> _getTemplateAllocation(String? template) {
    switch (template) {
      case '50-20-20-10 Plan':
        return {
          'Essentials': {
            'Housing': 0.30,
            'Groceries & Dining': 0.10,
            'Transportation': 0.05,
            'Healthcare': 0.05,
          },
          'Savings': {
            'Emergency Fund': 0.10,
            'Long-Term Savings': 0.05,
            'Retirement': 0.05,
          },
          'Personal': {
            'Entertainment': 0.10,
            'Hobbies & Personal Care': 0.10,
          },
          'Miscellaneous': {
            'Unexpected Costs': 0.05,
            'Gifts & Donations': 0.05,
          },
        };
      case '60-20-10-10 Plan':
        return {
          'Essentials': {
            'Housing': 0.35,
            'Groceries & Dining': 0.15,
            'Transportation': 0.05,
            'Healthcare': 0.05,
          },
          'Savings': {
            'Emergency Fund': 0.10,
            'Long-Term Savings': 0.05,
            'Retirement': 0.05,
          },
          'Personal': {
            'Entertainment': 0.05,
            'Hobbies & Personal Care': 0.05,
          },
          'Miscellaneous': {
            'Unexpected Costs': 0.05,
            'Gifts & Donations': 0.05,
          },
        };
      case '40-30-20-10 Plan':
        return {
          'Essentials': {
            'Housing': 0.20,
            'Groceries & Dining': 0.10,
            'Transportation': 0.05,
            'Healthcare': 0.05,
          },
          'Savings': {
            'Debt Repayment': 0.15,
            'Emergency Fund': 0.05,
            'Long-Term Savings': 0.05,
            'Retirement': 0.05,
          },
          'Personal': {
            'Entertainment': 0.10,
            'Hobbies & Personal Care': 0.10,
          },
          'Miscellaneous': {
            'Unexpected Costs': 0.05,
            'Gifts & Donations': 0.05,
          },
        };
      default:
        return {};
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Center(
          child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation<Color>(Colors.green),
      ));
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _error!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                padding:
                    const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
              onPressed: _fetchBudgetDetails,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    final allocations = _budget['allocations'] as Map<String, dynamic>?;
    if (allocations == null) {
      return const Center(child: Text('No budget data available'));
    }

    final monthlyBudget = double.tryParse(_monthlyBudgetController.text) ?? 0;
    final weeklyBudget = monthlyBudget / 4.33;

    return Theme(
      data: Theme.of(context).copyWith(
        cardTheme: CardTheme(
          elevation: 2,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      ),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildMainBudgetCard(),
            const SizedBox(height: 24),
            ..._buildCategoryCards(allocations, monthlyBudget, weeklyBudget),
          ],
        ),
      ),
    );
  }

  Widget _buildMainBudgetCard() {
    return Card(
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF4CAF50), Color(0xFF66BB6A)],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      _selectedTemplate ?? 'Custom Plan',
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      _isEditing ? Icons.save_rounded : Icons.edit_rounded,
                      color: Colors.white,
                    ),
                    onPressed: () {
                      if (_isEditing) {
                        _updateBudget();
                      } else {
                        setState(() {
                          _isEditing = true;
                        });
                      }
                    },
                  ),
                ],
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _monthlyBudgetController,
                enabled: _isEditing,
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Monthly Budget (₹)',
                  labelStyle: const TextStyle(color: Colors.white70),
                  prefixIcon:
                      const Icon(Icons.currency_rupee, color: Colors.white70),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Colors.white70),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Colors.white),
                  ),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.1),
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.white.withOpacity(0.1),
                ),
                child: DropdownButton<String>(
                  value: _selectedTemplate,
                  isExpanded: true,
                  dropdownColor: Colors.green,
                  style: const TextStyle(color: Colors.white),
                  icon: const Icon(Icons.arrow_drop_down, color: Colors.white),
                  underline: Container(),
                  items: [
                    '50-20-20-10 Plan',
                    '60-20-10-10 Plan',
                    '40-30-20-10 Plan',
                  ].map((String plan) {
                    return DropdownMenuItem<String>(
                      value: plan,
                      child: Text(plan),
                    );
                  }).toList(),
                  onChanged: _isEditing
                      ? (String? newValue) {
                          setState(() {
                            _selectedTemplate = newValue;
                            _budget['allocations'] =
                                _getTemplateAllocation(newValue);
                          });
                        }
                      : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildCategoryCards(
    Map<String, dynamic> allocations,
    double monthlyBudget,
    double weeklyBudget,
  ) {
    final categoryColors = {
      'Essentials': Colors.green[50],
      'Savings': Colors.green[100],
      'Personal': Colors.lightGreen[50],
      'Miscellaneous': Colors.teal[50],
    };

    return allocations.entries.map((category) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 16.0),
        child: Card(
          color: categoryColors[category.key] ?? Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.green.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        _getCategoryIcon(category.key),
                        color: Colors.green,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      category.key,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                  ],
                ),
                const Divider(height: 24),
                ..._buildCategoryItems(
                  category.value as Map<String, dynamic>,
                  monthlyBudget,
                  weeklyBudget,
                ),
              ],
            ),
          ),
        ),
      );
    }).toList();
  }

  List<Widget> _buildCategoryItems(
    Map<String, dynamic> items,
    double monthlyBudget,
    double weeklyBudget,
  ) {
    return items.entries.map((item) {
      final percentage = item.value as double;
      final monthlyAmount = monthlyBudget * percentage;
      final weeklyAmount = weeklyBudget * percentage;

      return Padding(
        padding: const EdgeInsets.only(bottom: 12.0),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      item.key,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${(percentage * 100).toStringAsFixed(1)}%',
                      style: const TextStyle(
                        color: Colors.green,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  _buildAmountCard(
                    'Monthly',
                    monthlyAmount,
                    Icons.calendar_month_rounded,
                  ),
                  const SizedBox(width: 8),
                  _buildAmountCard(
                    'Weekly',
                    weeklyAmount,
                    Icons.view_week_rounded,
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }).toList();
  }

  Widget _buildAmountCard(String label, double amount, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
        decoration: BoxDecoration(
          color: Colors.grey[50],
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: Colors.grey[200]!,
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              size: 16,
              color: Colors.grey[600],
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '₹${amount.toStringAsFixed(0)}',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Essentials':
        return Icons.home_rounded;
      case 'Savings':
        return Icons.savings_rounded;
      case 'Personal':
        return Icons.person_rounded;
      case 'Miscellaneous':
        return Icons.more_horiz_rounded;
      default:
        return Icons.category_rounded;
    }
  }

  @override
  void dispose() {
    _monthlyBudgetController.dispose();
    super.dispose();
  }
}
