import 'package:flutter/material.dart';
import 'custom_drawer.dart'; // Import the custom drawer
import 'challenges_screen.dart';
import 'leaderboard_screen.dart';
import 'wallet_screen.dart';

class CommunityScreen extends StatefulWidget {
  @override
  _CommunityScreenState createState() => _CommunityScreenState();
}

class _CommunityScreenState extends State<CommunityScreen> {
  // Track which screen to show in the body
  int _selectedIndex = 0;

  // Define the list of screens to display when switching tabs
  static List<Widget> _pages = <Widget>[
    ChallengesScreen(), // Index 0
    LeaderboardScreen(), // Index 1
    WalletScreen(
      initialAmount: 0.0,
      userId: '',
    ), // Index 2
  ];

  // Define the list of titles for each screen
  static List<String> _titles = <String>[
    'Challenges', // Title for index 0
    'Leaderboard', // Title for index 1
    'Wallet', // Title for index 2
  ];

  // Handle the tap on the bottom navigation bar
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index; // Update the selected index
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_selectedIndex]), // Dynamically change the title
        leading: Builder(
          builder: (context) {
            return IconButton(
              icon: Icon(Icons.menu),
              onPressed: () {
                Scaffold.of(context).openDrawer(); // Open the drawer
              },
            );
          },
        ),
      ),
      drawer: CustomDrawer(), // Use the centralized drawer
      body: _pages[_selectedIndex], // Swap the body based on the selected tab
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.flag),
            label: 'Challenges',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.leaderboard),
            label: 'Leaderboard',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.wallet_giftcard),
            label: 'Wallet',
          ),
        ],
        currentIndex: _selectedIndex, // Highlight the current tab
        selectedItemColor: Colors.green,
        onTap: _onItemTapped, // Change the page on tap
      ),
    );
  }
}
