import 'package:flutter/material.dart';
import 'budget_creation_page_2.dart';

class BudgetCreationPage1 extends StatelessWidget {
  final Color primaryGreen = Color(0xFF4CAF50);
  final Color lightGreen = Color(0xFFE8F5E9);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Let's Create\nYour Budget",
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: primaryGreen,
                  height: 1.2,
                ),
              ),
              SizedBox(height: 24),
              Text(
                "Before we start, let's understand a few key terms:",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: 24),
              _buildTermCard(
                  context,
                  "Essentials",
                  "Necessary living expenses to sustain your lifestyle, including housing, groceries, transportation, and healthcare.",
                  Icons.home),
              _buildTermCard(
                  context,
                  "Savings",
                  "Portion dedicated to building financial security, including emergency funds, long-term savings, and retirement contributions.",
                  Icons.savings),
              _buildTermCard(
                  context,
                  "Personal",
                  "Spending on enjoyment and lifestyle enhancement, such as entertainment, hobbies, and personal care.",
                  Icons.person),
              _buildTermCard(
                  context,
                  "Miscellaneous",
                  "Flexible category for occasional and unplanned expenses, including unexpected costs and gifts.",
                  Icons.more_horiz),
              SizedBox(height: 32),
              Center(
                child: ElevatedButton(
                  child: Text('Next', style: TextStyle(fontSize: 18)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryGreen,
                    padding: EdgeInsets.symmetric(horizontal: 48, vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => BudgetCreationPage2()),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTermCard(
      BuildContext context, String title, String description, IconData icon) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: lightGreen,
        borderRadius: BorderRadius.circular(16),
      ),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        leading: Icon(icon, color: primaryGreen, size: 32),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        subtitle: Text(
          description,
          style: TextStyle(
            fontSize: 14,
            color: Colors.black54,
          ),
        ),
      ),
    );
  }
}
