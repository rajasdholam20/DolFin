import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'custom_drawer.dart';

class RedeemScreen extends StatefulWidget {
  @override
  _RedeemScreenState createState() => _RedeemScreenState();
}

class _RedeemScreenState extends State<RedeemScreen> {
  int totalGems = 0; // Initial gems value
  final List<Map<String, dynamic>> offers = [];
  List<String> redeemedOffers = []; // To store redeemed offer IDs

  @override
  void initState() {
    super.initState();
    fetchGems();
    fetchOffers();
  }

  Future<void> fetchGems() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        final doc = await FirebaseFirestore.instance
            .collection('users')
            .doc(user.uid)
            .get();
        setState(() {
          totalGems = doc['gems'] ?? 0;
          redeemedOffers = List<String>.from(doc['redeemedOffers'] ?? []);
        });
      }
    } catch (e) {
      print('Error fetching gems: $e');
    }
  }

  Future<void> fetchOffers() async {
    try {
      final snapshot =
          await FirebaseFirestore.instance.collection('redeem').get();
      setState(() {
        offers.clear();
        for (var doc in snapshot.docs) {
          var data = doc.data();
          data['id'] = doc.id; // Include the document ID
          offers.add(data);
        }
      });
    } catch (e) {
      print('Error fetching offers: $e');
    }
  }

  Future<void> redeemOffer(int gemsRequired, String offerId) async {
    if (totalGems >= gemsRequired) {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null) {
        try {
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .update({
            'gems': totalGems - gemsRequired,
            'redeemedOffers': FieldValue.arrayUnion([offerId]),
          });
          setState(() {
            totalGems -= gemsRequired;
            redeemedOffers.add(offerId);
          });
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Redeem Successful'),
              content: Text('You have successfully redeemed the offer.'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text('OK'),
                ),
              ],
            ),
          );
        } catch (e) {
          print('Error redeeming offer: $e');
        }
      }
    } else {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Insufficient Gems'),
          content: Text('You do not have enough gems to redeem this offer.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Redeem Rewards'),
        backgroundColor: Colors.teal,
        elevation: 0,
      ),
      drawer: CustomDrawer(),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal, Colors.tealAccent],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Total Gems: $totalGems',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: ListView.builder(
                  itemCount: offers.length,
                  itemBuilder: (context, index) {
                    final offer = offers[index];
                    final offerId = offer['id'];
                    bool isRedeemed = redeemedOffers.contains(offerId);

                    // Convert Firestore Timestamp to DateTime
                    DateTime expiryDate = offer['expiry'].toDate();
                    // Format the DateTime object to a human-readable string
                    String formattedDate =
                        DateFormat('yyyy-MM-dd').format(expiryDate);
                    return Opacity(
                      opacity: isRedeemed ? 0.5 : 1.0,
                      child: Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        margin: EdgeInsets.symmetric(vertical: 8.0),
                        elevation: 8,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            gradient: LinearGradient(
                              colors: [Colors.white, Colors.teal[50]!],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                          ),
                          padding: const EdgeInsets.all(16.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: 80,
                                height: 80,
                                decoration: BoxDecoration(
                                  color: Colors.teal,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Center(
                                  child: Icon(
                                    Icons.card_giftcard,
                                    color: Colors.white,
                                    size: 40,
                                  ),
                                ),
                              ),
                              SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      offer['name'] ?? 'No Name',
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.teal[800],
                                      ),
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      offer['desc'] ?? 'No Description',
                                      style: TextStyle(
                                        color: Colors.teal[600],
                                      ),
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      'Expiry: $formattedDate',
                                      style: TextStyle(
                                        color: Colors.redAccent,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    SizedBox(height: 8),
                                    Text(
                                      'Gems Required: ${offer['gems']}',
                                      style: TextStyle(
                                        color: Colors.teal[900],
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    SizedBox(height: 12),
                                    ElevatedButton(
                                      onPressed: isRedeemed
                                          ? null
                                          : () {
                                              final offerId = offer['id'];
                                              if (offerId != null) {
                                                redeemOffer(offer['gems'] ?? 0,
                                                    offerId);
                                              }
                                            },
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.teal,
                                        shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(8),
                                        ),
                                        padding: EdgeInsets.symmetric(
                                          vertical: 12,
                                          horizontal: 20,
                                        ),
                                      ),
                                      child: Text(
                                        isRedeemed ? 'Redeemed' : 'Redeem Now',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
