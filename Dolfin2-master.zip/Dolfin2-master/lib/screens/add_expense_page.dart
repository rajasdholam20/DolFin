import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AddExpensePage extends StatefulWidget {
  @override
  _AddExpensePageState createState() => _AddExpensePageState();
}

class _AddExpensePageState extends State<AddExpensePage> {
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  String? _selectedExpenseType;
  String? _selectedExpenseCategory;
  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();
  bool showToday = true; // Toggle for Today or Month

  final Map<String, List<String>> expenseCategories = {
    'Miscellaneous': ['Unexpected Costs', 'Gift and Destinations'],
    'Savings': ['Emergency Fund', 'Long Term Savings', 'Entertainment'],
    'Personal': ['Entertainment', 'Hobbies', 'Personal Care'],
    'Essentials': ['Rent', 'Utilities', 'Groceries'],
    'Other': [] // No categories for "Other"
  };

  final Color backgroundColor = Color(0xFF00C49A); // Green background
  final Color cardColor = Color(0xFF282B3D); // Dark card color
  final Color textColor = Colors.white;
  final Color accentColor = Color(0xFFFFD700); // Accent color (yellow)

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        title: Text("Add Transaction", style: TextStyle(color: textColor)),
        backgroundColor: backgroundColor,
        elevation: 0,
        iconTheme: IconThemeData(color: textColor),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 16),
            // Amount input with virtual keypad
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              style: TextStyle(color: textColor),
              decoration: InputDecoration(
                labelText: "Amount (₹)",
                labelStyle: TextStyle(color: textColor),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: textColor),
                ),
              ),
            ),
            SizedBox(height: 16),
            // Expense Name input
            TextField(
              controller: _nameController,
              style: TextStyle(color: textColor),
              decoration: InputDecoration(
                labelText: "Expense Name",
                labelStyle: TextStyle(color: textColor),
                enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: textColor),
                ),
              ),
            ),
            SizedBox(height: 16),
            // Expense Type Dropdown
            DropdownButton<String>(
              value: _selectedExpenseType,
              hint: Text("Select Expense Type",
                  style: TextStyle(color: textColor)),
              dropdownColor: cardColor,
              iconEnabledColor: textColor,
              items: expenseCategories.keys.map((String type) {
                return DropdownMenuItem<String>(
                  value: type,
                  child: Text(type, style: TextStyle(color: textColor)),
                );
              }).toList(),
              onChanged: (String? newType) {
                setState(() {
                  _selectedExpenseType = newType;
                  _selectedExpenseCategory =
                      null; // Reset category when type changes
                });
              },
            ),
            SizedBox(height: 16),
            // Expense Category Dropdown (only if type is not "Other")
            if (_selectedExpenseType != null && _selectedExpenseType != "Other")
              DropdownButton<String>(
                value: _selectedExpenseCategory,
                hint: Text("Select Expense Category",
                    style: TextStyle(color: textColor)),
                dropdownColor: cardColor,
                iconEnabledColor: textColor,
                items: expenseCategories[_selectedExpenseType]!
                    .map((String category) {
                  return DropdownMenuItem<String>(
                    value: category,
                    child: Text(category, style: TextStyle(color: textColor)),
                  );
                }).toList(),
                onChanged: (String? newCategory) {
                  setState(() {
                    _selectedExpenseCategory = newCategory;
                  });
                },
              ),
            SizedBox(height: 16),
            // Date and Time Picker
            Row(
              children: [
                GestureDetector(
                  onTap: _selectDate,
                  child: Row(
                    children: [
                      Icon(Icons.calendar_today, color: textColor),
                      SizedBox(width: 10),
                      Text(
                        "${_selectedDate.toLocal()}".split(' ')[0],
                        style: TextStyle(color: textColor),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 20),
                GestureDetector(
                  onTap: _selectTime,
                  child: Row(
                    children: [
                      Icon(Icons.access_time, color: textColor),
                      SizedBox(width: 10),
                      Text(
                        _selectedTime.format(context),
                        style: TextStyle(color: textColor),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            // Add Button
            ElevatedButton(
              onPressed: _addTransaction,
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.black,
                backgroundColor: accentColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
              child: Center(
                child: Text(
                  "Add Expense",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime() async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
    );
    if (picked != null && picked != _selectedTime) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  void _addTransaction() async {
    final amount = _amountController.text;
    final name = _nameController.text;
    final type = _selectedExpenseType;
    final category =
        _selectedExpenseType == "Other" ? "None" : _selectedExpenseCategory;
    final date = "${_selectedDate.toLocal()}".split(' ')[0];
    final time = _selectedTime.format(context);

    if (amount.isNotEmpty && name.isNotEmpty && type != null) {
      try {
        // Get the current user
        User? user = FirebaseAuth.instance.currentUser;
        if (user != null) {
          // Reference to the user's document in Firestore
          DocumentReference userDoc =
              FirebaseFirestore.instance.collection('users').doc(user.uid);

          // Check if the user document exists
          DocumentSnapshot snapshot = await userDoc.get();
          if (!snapshot.exists) {
            // If document doesn't exist, create it and initialize expenses as an empty array
            await userDoc.set({
              'expenses': [],
            });
          }

          // Add expense to Firestore
          await userDoc.update({
            'expenses': FieldValue.arrayUnion([
              // Add to the array
              {
                'amount': amount,
                'name': name,
                'type': type,
                'category': category,
                'date': date,
                'time': time,
              }
            ])
          });

          _clearForm();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Expense added successfully!")),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error: ${e.toString()}")),
        );
      }
    }
  }

  void _clearForm() {
    _amountController.clear();
    _nameController.clear();
    _selectedExpenseType = null;
    _selectedExpenseCategory = null;
  }
}
