import 'package:dolfin/screens/expense_page.dart';
import 'package:flutter/material.dart';
import 'budget_page.dart';
import 'expense_analysis_screen.dart';
import 'add_expense_page.dart';
import 'custom_drawer.dart';
import 'profile_screen.dart';

class ExpenseTrackerScreen extends StatefulWidget {
  @override
  _ExpenseTrackerScreenState createState() => _ExpenseTrackerScreenState();
}

class _ExpenseTrackerScreenState extends State<ExpenseTrackerScreen> {
  int _selectedIndex = 1;

  static List<Widget> _pages = <Widget>[
    BudgetPage(),
    ExpensePage(),
    AddExpensePage(),
    ExpenseAnalysisScreen(),
    ProfileScreen()
  ];

  static List<String> _titles = <String>[
    'Budget',
    'Track Expenses',
    'Add Expense',
    'Analysis',
    'Profile'
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_selectedIndex]),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              // Add logout functionality here
            },
          ),
        ],
      ),
      drawer: CustomDrawer(),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomAppBar(
        shape: CircularNotchedRectangle(),
        notchMargin: 6,
        child: Container(
          height: 80,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              _buildNavItem(
                icon: Icons.attach_money,
                label: 'Budget',
                index: 0,
              ),
              _buildNavItem(
                icon: Icons.track_changes,
                label: 'Track',
                index: 1,
              ),
              // Center space for the floating action button
              _buildNavItem(
                icon: Icons.analytics,
                label: 'Analysis',
                index: 3,
              ),
              _buildNavItem(
                icon: Icons.person,
                label: 'Profile',
                index: 4,
              ),
            ],
          ),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        elevation: 0,
        shape: CircleBorder(),
        backgroundColor: Colors.green,
        child: Icon(Icons.add, size: 30, color: Colors.white),
        onPressed: () => _onItemTapped(2),
      ),
    );
  }

  Widget _buildNavItem(
      {required IconData icon, required String label, required int index}) {
    final isSelected = _selectedIndex == index;
    return Expanded(
      child: Tooltip(
        message: label,
        child: GestureDetector(
          onTap: () => _onItemTapped(index),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: isSelected ? Colors.green[500] : Colors.grey[700],
                size: 30,
              ),
              SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.black : Colors.grey[700],
                  fontSize: 13,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
