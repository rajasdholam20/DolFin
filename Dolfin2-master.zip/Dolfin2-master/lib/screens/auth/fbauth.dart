import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthHelper {
  static User? get user => FirebaseAuth.instance.currentUser;

  static bool get isUserSignedIn {
    return user != null;
  }

  static Future<void> createUserWithEmailAndPassword({
    required String email,
    required String password,
    required String name, // Assuming you're capturing the user's name during signup
  }) async {
    try {
      // Create user with email and password
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password.trim(),
      );

      // Check if the user is signed in
      if (isUserSignedIn) {
        // Get the current user's ID
        String userId = FirebaseAuth.instance.currentUser!.uid;

        // Add user information to Firestore
        await FirebaseFirestore.instance.collection('users').doc(userId).set({
          'name': name,
          'email': email,
          'gems': 0, // Initialize gems to 0
          'wallet_balance': 0.0, // Initialize wallet balance to 0
        });
      }
    } catch (e) {
      print("Error creating user: $e");
      throw Exception('Failed to create user: $e');
    }
  }

  // Sign-in function remains the same
  static Future<void> signInWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email.trim(),
        password: password.trim(),
      );
    } catch (e) {
      print("Error signing in: $e");
      throw Exception('Failed to sign in: $e');
    }
  }

  static Future<void> signOut() async {
    await FirebaseAuth.instance.signOut();
  }
}
