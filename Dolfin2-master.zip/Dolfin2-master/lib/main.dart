import 'package:dolfin/screens/budget_creation_page_1.dart';
import 'package:dolfin/screens/budget_creation_page_2.dart';
import 'package:dolfin/screens/budget_creation_page_3.dart';
import 'package:dolfin/screens/budget_creation_page_4.dart';
import 'package:flutter/foundation.dart'; // For kIsWeb
import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/intro_screen.dart';
import 'screens/quiz_screen.dart';
import 'screens/login_signup_screen.dart';
import 'screens/expense_tracker_screen.dart';
import 'screens/budget_page.dart';
import 'screens/expense_analysis_screen.dart';
import 'screens/community_screen.dart';
import 'screens/challenges_screen.dart';
import 'screens/dice_roll_challenge_page.dart';
import 'screens/hi_lo_challenge_page.dart';
import 'screens/challenge_participation_page.dart';
import 'screens/leaderboard_screen.dart';
import 'screens/wallet_screen.dart';
import 'screens/redeem_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/add_expense_page.dart'; // Import the new Add Expense Page
import 'package:firebase_core/firebase_core.dart';

// Import admin panel screens
import 'admin/admin_login_screen.dart';
import 'admin/admin_home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Ensure binding is initialized
  await Firebase.initializeApp(); // Initialize Firebase
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'App Skeleton',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // Use conditional initialRoute based on platform
      initialRoute: kIsWeb ? '/admin_login' : '/',
      routes: {
        '/': (context) => kIsWeb ? AdminLoginScreen() : SplashScreen(),
        '/intro': (context) => kIsWeb ? AdminHomeScreen() : IntroScreen(),
        '/quiz': (context) => kIsWeb ? AdminHomeScreen() : QuizScreen(),
        '/login_signup': (context) =>
            kIsWeb ? AdminHomeScreen() : LoginSignupScreen(),
        '/budget_template': (context) =>
            kIsWeb ? AdminHomeScreen() : BudgetCreationPage1(),
        '/chat': (context) =>
            kIsWeb ? AdminHomeScreen() : BudgetCreationPage2(),
        '/budget_result': (context) => kIsWeb
            ? AdminHomeScreen()
            : BudgetCreationPage3(selectedTemplate: ''),
        '/budget_creation': (context) => kIsWeb
            ? AdminHomeScreen()
            : BudgetCreationPage4(
                selectedTemplate: '', monthlyBudget: 0, allocations: {}),
        '/home': (context) =>
            kIsWeb ? AdminHomeScreen() : ExpenseTrackerScreen(),
        '/budget_page': (context) => kIsWeb ? AdminHomeScreen() : BudgetPage(),
        '/expense_analysis': (context) =>
            kIsWeb ? AdminHomeScreen() : ExpenseAnalysisScreen(),
        '/community': (context) =>
            kIsWeb ? AdminHomeScreen() : CommunityScreen(),
        '/challenges': (context) =>
            kIsWeb ? AdminHomeScreen() : ChallengesScreen(),
        '/diceRollChallenge': (context) =>
            kIsWeb ? AdminHomeScreen() : DiceRollChallengePage(),
        '/hiLoChallenge': (context) =>
            kIsWeb ? AdminHomeScreen() : HiLoChallengePage(),
        '/challengeParticipation': (context) => kIsWeb
            ? AdminHomeScreen()
            : ChallengeParticipationPage(
                title: '',
                description: '',
                gems: 0,
                expiry: '',
              ),
        '/leaderboard': (context) =>
            kIsWeb ? AdminHomeScreen() : LeaderboardScreen(),
        '/wallet': (context) => kIsWeb
            ? AdminHomeScreen()
            : WalletScreen(
                initialAmount: 0.0,
                userId: '',
              ),
        '/redeem': (context) => kIsWeb ? AdminHomeScreen() : RedeemScreen(),
        '/profile': (context) => kIsWeb ? AdminHomeScreen() : ProfileScreen(),
        '/add_expense': (context) => kIsWeb
            ? AdminHomeScreen()
            : AddExpensePage(), // Add Expense Page route

        // Admin routes
        '/admin_login': (context) => AdminLoginScreen(),
        '/admin_home': (context) => AdminHomeScreen(),
      },
    );
  }
}
