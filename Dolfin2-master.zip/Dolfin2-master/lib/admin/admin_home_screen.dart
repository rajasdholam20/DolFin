import 'package:flutter/material.dart';

class AdminHomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Dashboard'),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              // Log out and navigate back to login screen
              Navigator.pushReplacementNamed(context, '/admin_login');
            },
          ),
        ],
      ),
      body: Center(
        child: Text('Welcome to the Admin Dashboard!'),
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            DrawerHeader(
              child: Text('Admin Menu'),
            ),
            ListTile(
              title: Text('Manage Users'),
              onTap: () {
                // Handle navigation to user management screen (if any)
              },
            ),
            ListTile(
              title: Text('Settings'),
              onTap: () {
                // Handle navigation to settings
              },
            ),
          ],
        ),
      ),
    );
  }
}
